The compiler has been tested.
----
Need to now add:- Test cases and integrate with django
